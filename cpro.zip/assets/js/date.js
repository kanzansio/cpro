<script>
    var n = document.createElement('span');
    n.innerHTML = new Date().getFullYear();
    document.body.appendChild(n);
</script>